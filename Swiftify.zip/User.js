/*class User {
  constructor(username, password) {
    this.username = username;
    this.password = password;
  }

  toString() {
    alert("You have created an account");

    alert(username, password);
  }

  changePass(pass) {
    password = pass;
    alert("Your Password has successfully been changed");
  }

  getUsername(){
    return username;
  }
  getPassword(){
    return password;
  }
}*/