/*class Song {
  //static numSongs = 0;
  constructor(name, artist, album, image, video) {
    this.name = name;
    this.artist = artist;
    this.album = album;
    this.image = image;
    //this will be the image of the song/album cover that will show up if the ranking process
    this.video = video;
    //this will be the variable for the video link where users will be able to listen to the song when ranking 
  }

  getName() {
    return name;
  }
  getArtist() {
    return artist;
  }
  getAlbum() {
    return album;
  }
  getImage() {
    return image;
  }
  getVideo() {
    return video;
  }
}

*/