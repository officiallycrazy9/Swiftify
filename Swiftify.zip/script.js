/*

//Constant arrays to put user logins into
var userArr = [];

function saveUser(u, p) {
  confirm("Are you sure");
  var newU = new User(u, p);
  userArr.push(newU)
  alert("You have successfully created an account");

}

function login() {
  const name = document.getElementById("username");
  const pass = document.getElementById("password");
  checkLogin(usersArr, passArr, name, pass);

}

//checks user login to see if it exists
function checkLogin(arrU, arrP, u, p) {
  for (let i = 0; i < arrU.length; i++) {
    if (arrU[i] == u && arrP[i] == p) {
      return true;//if user is found, return true
    }
  }//end of for loop
  return false;//if user is not found, return false
}//end of search


//checks to see if username already exists
function checkUser(arr, u) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].getName() == u) {
      alert("This username already exists, please enter another one.");
      return true; //if user exists already, return true
    }
  }
  return false;//if user does not exists, return false
}



class User {
  constructor(username, password) {
    this.username = username;
    this.password = password;
  }

  toString() {
    alert("You have created an account");

    alert(username, password);
  }

  changePass(pass) {
    password = pass;
    alert("Your Password has successfully been changed");
  }

  getName() {
    return username;
  }
  getPass() {
    return password;
  }
}*/